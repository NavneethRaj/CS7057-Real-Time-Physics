#include "collision_manager.h"

#include "collision_detector.h"
#include "collision_resolver.h"

using namespace std;
using namespace collision;

void
CollisionManager::updateSimulation(
	float dt,
	bool draw_debug )
{
	//
}